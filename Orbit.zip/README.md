Well, I would say most of the basic
functionality is working as of
Feb 13, 2022.  One big issue I am having
is that the program exits with a code 3.
Obviously, something is wrong, but so far,
my searches have not revealed anything that
helps me find out what it is.  So for now,
well, there are more important things to
do.

Eventually I want to dispolay the Energy of
the objects, as well as things like Potential
Engergy, which, it seems, is difficult to
do if you have 2 or more moving bodies.
Also, things like angulare momentum, stuff
like that.  Sort of like being back in
Physics 21.
