//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Orbit.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_OrbitTYPE                   130
#define IDD_DIALOG_ADD_BODOES           310
#define IDC_EDIT_MASS                   1000
#define IDC_EDIT_VELOCITY_MAG           1001
#define IDC_EDIT_VELOCITY_ANGLE         1002
#define IDC_EDIT_POSITION_X             1003
#define IDC_EDIT_POSITION_Y             1004
#define IDC_STATIC_BODYCOLOR            1005
#define IDC_BUTTON_NEXTBODY             1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON_ADD_NEW__BODY        1007
#define IDC_STATIC_BODY_ID              1008
#define ID_SETUP_CREATEBODY             32771
#define ID_FILE_START                   32772
#define ID_FILE_PAUSE                   32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
